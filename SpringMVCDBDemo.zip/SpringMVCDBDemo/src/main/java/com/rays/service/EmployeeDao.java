package com.rays.service;

import com.rays.model.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee);

}
