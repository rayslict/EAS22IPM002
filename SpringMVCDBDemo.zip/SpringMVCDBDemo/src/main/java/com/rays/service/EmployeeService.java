package com.rays.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rays.model.Employee;
import com.rays.repo.EmployeeRepo;

@Service
public class EmployeeService implements EmployeeDao {

	@Autowired
	EmployeeRepo empRepo;
	
	@Override
	public void addEmployee(Employee employee) {				
		empRepo.save(employee);
	}

}
