package com.rays.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rays.dao.MovieService;
import com.rays.model.Movie;

@RestController
public class MovieController {
	
	@Autowired
	Movie movie;
	
	@Autowired
	MovieService movieService;
	
	@GetMapping("movies")
	public List<Movie> getAllMovies(){
	 return movieService.getAllMovies();
	}
	
	@PostMapping("movie")
	public Movie addMovie(@RequestBody Movie movie) {
		return movieService.addMovie(movie);
	}
	
	@GetMapping("movie/{id}")
	public Movie getMovie(@PathVariable("id") int id) {
		Movie mo = movieService.getMovieById(id);
		System.out.println(mo);
		//return new ResponseEntity<Movie>(mo, HttpStatus.OK);
		return mo;
	}
	
	@PutMapping("movie/{id}")
	public Movie updateMovie(@PathVariable(value = "id") int id, @RequestBody Movie movie) {
				movie.setId(id);
		return movieService.updateMovie(movie);
	}
	
	@DeleteMapping("movie/{id}")
	public ResponseEntity<?> deleteMovie(@PathVariable(value = "id") int id){
		movieService.deleteMovie(id);
		return ResponseEntity.ok().build();
	}
}
