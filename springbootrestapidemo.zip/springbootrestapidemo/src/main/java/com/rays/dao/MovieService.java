package com.rays.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rays.model.Movie;
import com.rays.repository.MovieRepository;

@Service
public class MovieService implements MovieDao {

	@Autowired
	MovieRepository movieRepository;
	
	@Override
	public Movie addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieRepository.save(movie);

	}

	@Override
	public List<Movie> getAllMovies() {
		return movieRepository.findAll();
	
	}

	@Override
	public Movie getMovieById(int id) {
		// TODO Auto-generated method stub
		return movieRepository.getById(id);
		
	}

	@Override
	public Movie updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		
		Movie mo = movieRepository.getById(movie.getId());
		
		mo.setMovieDirector(movie.getMovieDirector());
		mo.setMovieCategory(movie.getMovieCategory());
		return movieRepository.save(mo);
		
	}

	@Override
	public void deleteMovie(int id) {
		// TODO Auto-generated method stub
		Movie mo = movieRepository.getById(id);
		movieRepository.delete(mo);
	}

}
