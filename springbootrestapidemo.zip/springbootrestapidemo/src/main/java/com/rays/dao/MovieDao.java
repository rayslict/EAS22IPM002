package com.rays.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rays.model.Movie;

@Service
public interface MovieDao {

	public Movie addMovie(Movie movie);
	public List<Movie> getAllMovies();
	public Movie getMovieById(int id);
	public Movie updateMovie(Movie movie);
	public void deleteMovie(int id);
}
