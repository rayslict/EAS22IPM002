package com.rays.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rays.model.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

}
