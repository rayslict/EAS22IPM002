package com.rays.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Movie implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String movieName;
	private String movieDirector;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date movieReleaseDate;
	private double movieBudget;
	private String movieCategory;
	
	
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Movie(int id, String movieName, String movieDirector, Date movieReleaseDate, double movieBudget,
			String movieCategory) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.movieDirector = movieDirector;
		this.movieReleaseDate = movieReleaseDate;
		this.movieBudget = movieBudget;
		this.movieCategory = movieCategory;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieDirector() {
		return movieDirector;
	}
	public void setMovieDirector(String movieDirector) {
		this.movieDirector = movieDirector;
	}
	public Date getMovieReleaseDate() {
		return movieReleaseDate;
	}
	public void setMovieReleaseDate(Date movieReleaseDate) {
		this.movieReleaseDate = movieReleaseDate;
	}
	public double getMovieBudget() {
		return movieBudget;
	}
	public void setMovieBudget(double movieBudget) {
		this.movieBudget = movieBudget;
	}
	public String getMovieCategory() {
		return movieCategory;
	}
	public void setMovieCategory(String movieCategory) {
		this.movieCategory = movieCategory;
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", movieName=" + movieName + ", movieDirector=" + movieDirector
				+ ", movieReleaseDate=" + movieReleaseDate + ", movieBudget=" + movieBudget + ", movieCategory="
				+ movieCategory + "]";
	}
	
	
	

}
