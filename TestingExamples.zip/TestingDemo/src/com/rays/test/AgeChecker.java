package com.rays.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.rays.main.TestingDemo;

public class AgeChecker {

	@Test
	public void test() {
		TestingDemo td = new TestingDemo();
		boolean res = td.ageChecker(21);
		assertEquals(true, res);
	}

}
