package com.rays.test;

public class Calculator {
	 
    public int sum(int first, int second) {
        return first + second;
    }
}
