package com.rays.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.rays.main.MainDemo;

public class TestDmo {

	@Test
	public void test() {
		MainDemo demo = new MainDemo();
		boolean res1 = demo.checkAge(19);
		boolean res2 = demo.checkAge(12);
		assertEquals(true, res1);
		assertEquals(false, res2);
	}

}
