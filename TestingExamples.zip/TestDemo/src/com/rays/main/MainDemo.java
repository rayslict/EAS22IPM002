package com.rays.main;

public class MainDemo {
	
	public boolean checkAge(int age) {
		if(age>=18) {
			System.out.println("Eligible to Vote");
			return true;
		}else {
			System.out.println("Not Eligible to Vote");
			return false;
		}
	
	}

}
