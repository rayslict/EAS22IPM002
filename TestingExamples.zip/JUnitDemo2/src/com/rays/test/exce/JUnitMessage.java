package com.rays.test.exce;

public class JUnitMessage{

	private String message;

	public JUnitMessage(String message) {
		this.message = message;
	}

public void printMessage(){

	System.out.println(message); 
	int divide=1/0;
	//int a[]= {1,2,3,4};
	//System.out.println(a[5]);

}


}
