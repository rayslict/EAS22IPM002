import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.*;

public class JunitTestExample {

	private ArrayList testList;

	// The BeforeClass annotation indicates that the static method to
	// which is attached must be executed once and before all tests in the class.
	@BeforeClass
	public static void onceExecutedBeforeAll() {
		System.out.println("@BeforeClass: onceExecutedBeforeAll");
	}

	// The Before annotation indicates that this method must be executed before each
	// test in the class,so as to execute some preconditions necessary for the test
	@Before
	public void executedBeforeEach() {
		testList = new ArrayList();
		System.out.println("@Before: executedBeforeEach");
	}

	@Test
	public void EmptyCollection() {
		assertTrue(testList.isEmpty());
		System.out.println("@Test: EmptyArrayList");

	}

	@Test
	public void OneItemCollection() {
		testList.add("oneItem");
		testList.add("Second Item");
		assertEquals(1, testList.size());
		System.out.println("@Test: OneItemArrayList");
	}

}