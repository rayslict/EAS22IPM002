package com.rays.pojo;

public class Associates {

	private int assoId;
	private String assoName;
	private long assoMobile;
	private Address assoAddress;
	public Associates() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Associates(int assoId, String assoName, long assoMobile, Address assoAddress) {
		super();
		this.assoId = assoId;
		this.assoName = assoName;
		this.assoMobile = assoMobile;
		this.assoAddress = assoAddress;
	}
	@Override
	public String toString() {
		return "Associates [assoId=" + assoId + ", assoName=" + assoName + ", assoMobile=" + assoMobile
				+ ", assoAddress=" + assoAddress + "]";
	}
	
	
}
