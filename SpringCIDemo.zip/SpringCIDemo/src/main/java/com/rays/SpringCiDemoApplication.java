package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCiDemoApplication.class, args);
	}

}
