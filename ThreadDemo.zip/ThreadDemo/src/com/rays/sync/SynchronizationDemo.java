package com.rays.sync;

public class SynchronizationDemo {

	public static void main(String[] args) {
		
		Table table = new Table();
		Anuja anuja = new Anuja(table);
		Shalini shalini = new Shalini(table);
		anuja.start();
		shalini.start();
	}

}
