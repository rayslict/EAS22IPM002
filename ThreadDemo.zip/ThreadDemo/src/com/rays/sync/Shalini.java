package com.rays.sync;

public class Shalini extends Thread{
	Table t;
	public Shalini(Table t) {
		this.t = t;
	}
	public void run() {
		t.printTable(100);
	}
}
