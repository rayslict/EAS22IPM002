package com.rays.sync;

public class Anuja extends Thread{
	Table t;
	public Anuja(Table t) {
		this.t = t;
	}
	public void run() {
		t.printTable(5);
	}
}
