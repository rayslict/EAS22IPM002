package com.rays.multiple;

public class MultiThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main Starts Here...");
		Thread MT = new Thread("Raffic");
		System.out.println(MT);  // Thread[Raffic,5,main]
		Students st1 = new Students("Partha");
		Students st2 = new Students("Shailesh");
		Students st3 = new Students("Shubam");
		MT.sleep(10000);
		System.out.println("Main Ends Here...");
	}

}
