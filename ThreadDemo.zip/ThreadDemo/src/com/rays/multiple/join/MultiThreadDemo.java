package com.rays.multiple.join;

public class MultiThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main Starts Here...");
		Thread MT = new Thread("Raffic");
		System.out.println(MT);  // Thread[Raffic,5,main]
		Students st1 = new Students("Sainath");
		Students st2 = new Students("Mansuri");
		Students st3 = new Students("Dhaya");
		
		st1.ST.join();  //Waits for this thread to die. 
		System.out.println("Sainath Exited...");
		st2.ST.join();
		System.out.println("Mansuri Exited...");
		st3.ST.join();
		System.out.println("Dhaya Exited...");
		
		System.out.println("Main Ends Here...");
	}

}
