package com.rays.multiple.join;

public class Students implements Runnable{

	Thread ST;
	String threadName;
	public Students(String threadName) {
		this.threadName = threadName;
		ST = new Thread(this, threadName);
		System.out.println(ST);  // Thread[Sainath,5,main]
		ST.start();  // Runnable state
	}

	public void run() {
		
		for(int i=1;i<=6;i++) {
			System.out.println("Child Thread : "+threadName+"\t"+i);
			try {
				ST.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(threadName+"  Thread Terminate or Dead");
	}
	

}
