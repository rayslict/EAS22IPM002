package com.rays.single;

public class Student extends Thread{  // New state (creating Thread for this class)
	
	public Student() {
		Thread ST = new Thread("Shristi");
		System.out.println(ST);   // Thread[Shristi,5,main]
		start();  // Runnable state when you call start()
	}
	
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("Child Thread : "+i);
			try {
				sleep(500);  
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
