package com.rays.single;

public class Student2 implements Runnable{  // New state (creating Thread for this class)
	
	Thread ST;
	public Student2() {
		ST = new Thread(this,"Deepak");
		System.out.println(ST);   // Thread[Rishi,5,main]
		ST.start();  // Runnable state when you call start()
	}
	
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("Child Thread : "+i);
			try {
				ST.sleep(500);  
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
