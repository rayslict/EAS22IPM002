package com.rays.single;

public class SingleThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		Thread MT = new Thread("Raffic");
		System.out.println("From Main Method : "+MT);  // Thread[Raffic,5,main]
		new Student2();
		for(int i=1;i<=5;i++) {
			System.out.println("Main Thread : "+i);
			MT.sleep(1000);
		}

	}

}
