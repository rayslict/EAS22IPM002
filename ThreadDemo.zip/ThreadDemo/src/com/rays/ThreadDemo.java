package com.rays;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		
		Thread T = new Thread();
		System.out.println(T.currentThread());  // Thread[main,5,main]  1.main --> Thread Name 2.5 -->Priority 3.main--> Thread Group Name
		T.setName("Raffic");
		System.out.println(T);
		T.sleep(5000);
		System.out.println("Raffic");

	}

}
