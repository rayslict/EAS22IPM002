package com.rays.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.rays.conn.ConnectionDemo;
import com.rays.dao.pojo.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	Connection con;

	public EmployeeDaoImpl() {
		this.con = ConnectionDemo.createConnection();
	}

	public int insertEmployee(Employee emp) {
		int insert = 0;
		try {
			String qry = "insert into employee values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(qry);
			ps.setInt(1, emp.getEmpId());
			ps.setString(2, emp.getEmpName());
			ps.setInt(3, emp.getEmpAge());
			java.sql.Date joinDate = new java.sql.Date(emp.getEmpJoinDate().getTime());
			ps.setDate(4, joinDate);
			ps.setDouble(5, emp.getEmpSalary());
			insert = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error in insert Employee : " + e);
		}
		return insert;
	}

	public List<Employee> getAllEmployee() {

		List<Employee> empList = new ArrayList<Employee>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from employee");
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpAge(rs.getInt(3));
				emp.setEmpJoinDate(rs.getDate(4));
				emp.setEmpSalary(rs.getDouble(5));
				empList.add(emp);
			}
		} catch (Exception e) {
			System.out.println("Error in getAllEmployee :" + e);
		}
		return empList;
	}

	public Employee getEmployeeById(int empId) {
		Employee emp = null;
		try {
			PreparedStatement st = con.prepareStatement("select * from employee where empId=?");
			st.setInt(1, empId);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpAge(rs.getInt(3));
				emp.setEmpJoinDate(rs.getDate(4));
				emp.setEmpSalary(rs.getDouble(5));
			}
		} catch (Exception e) {
			System.out.println("Error in getEmployeeByID :" + e);
		}
		return emp;
	}

	public int updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
int update=0;
        
        try{
            PreparedStatement ps =con.prepareStatement("update employee set empName=?, empAge=?,empJoinDate=?,empSalary=? where empId = ?"); 
            
            ps.setString(1, emp.getEmpName());
            ps.setInt(2, emp.getEmpAge());
            java.sql.Date joinDate= new java.sql.Date(emp.getEmpJoinDate().getTime());
            ps.setDate(3, joinDate);
            ps.setDouble(4, emp.getEmpSalary());
            ps.setInt(5, emp.getEmpId());
            update = ps.executeUpdate();
            
        }catch(Exception e){
            System.out.println("Error in update Employee : " +e);
        }
        
        return update;
	}

	public int deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		int delete = 0;

		try {
			String qry = "delete from employee where empId=?";
			PreparedStatement ps = con.prepareStatement(qry);
			ps.setInt(1, empId);
			delete = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error Deleting Employee : " + e);

		}
		return delete;
	}

}
