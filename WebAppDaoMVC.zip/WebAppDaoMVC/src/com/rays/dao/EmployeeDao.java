package com.rays.dao;

import java.util.List;

import com.rays.dao.pojo.Employee;

public interface EmployeeDao {
	
	public int insertEmployee(Employee emp);
	public List<Employee> getAllEmployee();
	public Employee getEmployeeById(int empId);
	public int updateEmployee(Employee emp);
	public int deleteEmployee(int empId);

}
