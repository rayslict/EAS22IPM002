package com.rays.conn;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionDemo {
	static Connection con;
	
	public static Connection createConnection() {
		String url = "jdbc:mysql://localhost:3306/jdbcdemo";
		String user = "root";
		String password = "raysrmr";
		try {
			Driver d = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d);
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			System.out.println("Error in Connection :"+e);
		}
		return con;
	}

}
