package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.dao.EmployeeDao;
import com.rays.dao.EmployeeDaoImpl;
import com.rays.dao.pojo.Employee;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int empId = Integer.parseInt(request.getParameter("empId"));
		String empName = request.getParameter("empName");
		int empAge = Integer.parseInt(request.getParameter("empAge"));
		String jDate = request.getParameter("empJoinDate");
		Date empJoinDate = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			empJoinDate = sdf.parse(jDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Double empSalary = Double.parseDouble(request.getParameter("empSalary"));
		Employee employee = new Employee(empId, empName, empAge, empJoinDate, empSalary);
		//Update Employee
		EmployeeDao employeeDao = new EmployeeDaoImpl();
		int count = employeeDao.updateEmployee(employee);
		//Get All Employee Details
		List<Employee> employees = employeeDao.getAllEmployee();
		request.setAttribute("emplist", employees);
		
		RequestDispatcher rDispatcher = request.getRequestDispatcher("showall.jsp");
		if(count>0) {						
			out.println("<font color='green' size=10>You have been Updated successfully</font>");
			rDispatcher.include(request, response);
		}else {			
			out.println("<font color='red' size=10>Problem with Updation ..Try Again</font>");
			rDispatcher.include(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
