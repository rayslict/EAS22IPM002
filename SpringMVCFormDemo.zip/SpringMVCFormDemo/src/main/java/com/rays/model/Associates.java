package com.rays.model;

import org.springframework.stereotype.Component;

@Component
public class Associates {

	private int assoId;
	private String assoName;
	private long assoMobile;
	public Associates() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Associates(int assoId, String assoName, long assoMobile) {
		super();
		this.assoId = assoId;
		this.assoName = assoName;
		this.assoMobile = assoMobile;
	}
	public int getAssoId() {
		return assoId;
	}
	public void setAssoId(int assoId) {
		this.assoId = assoId;
	}
	public String getAssoName() {
		return assoName;
	}
	public void setAssoName(String assoName) {
		this.assoName = assoName;
	}
	public long getAssoMobile() {
		return assoMobile;
	}
	public void setAssoMobile(long assoMobile) {
		this.assoMobile = assoMobile;
	}
	@Override
	public String toString() {
		return "Associates [assoId=" + assoId + ", assoName=" + assoName + ", assoMobile=" + assoMobile + "]";
	}
	
	
}
