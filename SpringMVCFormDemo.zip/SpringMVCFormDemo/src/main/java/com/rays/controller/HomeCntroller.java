package com.rays.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rays.model.Associates;

@Controller
public class HomeCntroller {

	@Autowired
	Associates asso;
	
	@RequestMapping("/")
	public String loadForm() {
		return "index";
	}
	
	@RequestMapping("/getdata")
	public String getForm(@RequestParam("assoId") int assoId, @RequestParam("assoName") String assoName, @RequestParam("assoMobile") long assoMobile, Model model) {
		asso.setAssoId(assoId);
		asso.setAssoName(assoName);
		asso.setAssoMobile(assoMobile);
		model.addAttribute("assoObj", asso);
		return "display";
		
	}
}
