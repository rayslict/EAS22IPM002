function add(){
    var a=10;
    var b=20;
    var c=a+b;
    document.write(c)
}

function add1(){
    var a=10;
    var b=20;
    var c=a+b;
    return c;
}
add();
document.write(add1())