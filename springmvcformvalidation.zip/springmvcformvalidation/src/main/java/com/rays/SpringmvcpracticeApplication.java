package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcpracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmvcpracticeApplication.class, args);
	}

}
