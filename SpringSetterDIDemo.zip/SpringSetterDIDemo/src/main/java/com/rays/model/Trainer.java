package com.rays.model;

public class Trainer {

	private int tId;
	private String tName;
	private long tMobile;
	@Override
	public String toString() {
		return "Trainer [tId=" + tId + ", tName=" + tName + ", tMobile=" + tMobile + "]";
	}
	public int gettId() {
		return tId;
	}
	public void settId(int tId) {
		this.tId = tId;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public long gettMobile() {
		return tMobile;
	}
	public void settMobile(long tMobile) {
		this.tMobile = tMobile;
	}
	
	
}
