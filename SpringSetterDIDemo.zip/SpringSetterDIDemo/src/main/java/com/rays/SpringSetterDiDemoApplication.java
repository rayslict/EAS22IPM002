package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSetterDiDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSetterDiDemoApplication.class, args);
	}

}
