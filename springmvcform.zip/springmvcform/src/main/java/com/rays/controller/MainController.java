package com.rays.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rays.model.Employee;

@Controller
public class MainController {

	@Autowired
	Employee employee;

	@RequestMapping("/")
	public String home() {
		return "index";
	}

	@RequestMapping("register")
	/* public ModelAndView registrtionForm(ModelAndView model) { */
	public ModelAndView registrtionForm(ModelAndView model) {
		String msg = "Register Page";
		//model.addAttribute("msg", msg);
		//model.addAttribute("emp", employee);
		model.addObject("emp", employee);  // for ModelAndView class
		model.setViewName("registrtion");  // for ModelAndView class
		//return "registrtion";
		return model;
	}

	@RequestMapping("submitform")
	public String submitForm(@ModelAttribute("emp") Employee emp) {

		System.out.println(emp);
		// m.addAttribute("emp", emp);
		return "showdetails";

	}

}
