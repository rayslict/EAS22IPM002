package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAutowiringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAutowiringDemoApplication.class, args);
	}

}
