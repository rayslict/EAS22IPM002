package com.rays.model;

public class Associates {

	private int assoId;
	private String assoName;
	private long assoMobile;
	public Associates() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Associates(int assoId, String assoName, long assoMobile) {
		super();
		this.assoId = assoId;
		this.assoName = assoName;
		this.assoMobile = assoMobile;
	}
	@Override
	public String toString() {
		return "Associates [assoId=" + assoId + ", assoName=" + assoName + ", assoMobile=" + assoMobile + "]";
	}
	
	
}
