package com.rays.dao.customerdao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rays.model.Customer;

@Service
public interface CustomerDao {
	
	public List<Customer> getAllCustomers();

}
