package com.rays.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rays.model.Customer;

@Repository
public interface CustomerRespository extends JpaRepository<Customer, Integer>{
	
	

}
