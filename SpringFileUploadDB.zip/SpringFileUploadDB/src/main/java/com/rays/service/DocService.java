package com.rays.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.rays.model.Docs;
import com.rays.repo.DocRepo;

@Service
public class DocService {
	
	@Autowired
	DocRepo docRepo;
	
	public Docs saveDoc(MultipartFile file) {
		
	 String docName = file.getOriginalFilename();
	 
	 try {
		Docs docs = new Docs(docName, file.getContentType(), file.getBytes());
		return docRepo.save(docs);
	} catch (Exception e) {
		System.out.println("Error in save files...");
	}
		return null;
	}
	
	public Docs getDocs(Integer id) {
		return docRepo.findById(id).get();
	}

	public List<Docs> getAllDocs(){
		return docRepo.findAll();
	}
}
