package com.rays.model;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.GeneratorType;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Docs {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)  
	private Integer id;
	
	private String docName;
	private String docType;
	
	@Lob
	private byte[] docDate;

	public Docs() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Docs(String docName, String docType, byte[] docDate) {
		super();
		
		this.docName = docName;
		this.docType = docType;
		this.docDate = docDate;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public byte[] getDocDate() {
		return docDate;
	}

	public void setDocDate(byte[] docDate) {
		this.docDate = docDate;
	}



	@Override
	public String toString() {
		return "Docs [id=" + id + ", docName=" + docName + ", docType=" + docType + ", docDate="
				+ Arrays.toString(docDate) + "]";
	}
	
	
}
