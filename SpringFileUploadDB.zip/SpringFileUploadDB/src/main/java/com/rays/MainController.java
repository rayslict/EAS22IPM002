package com.rays;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


import com.rays.model.Docs;
import com.rays.service.DocService;

@Controller
public class MainController {

	@Autowired
	DocService docService;
	
	@RequestMapping("/")
	public String get(Model model) {
		List<Docs> listDocs = docService.getAllDocs();
		model.addAttribute("docs", listDocs);
		return "index";
	}
	
	@RequestMapping("/uploadDocs")
	public String uploadDocs(@RequestParam("files") MultipartFile[] files) {
		
		for(MultipartFile m: files) {
			docService.saveDoc(m);
		}
		
		return "redirect:/";
	}
	@GetMapping("/downloadFile/{id}")
	public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable Integer id){
		Docs docs = docService.getDocs(id);
		System.out.println("docs");
		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType(docs.getDocType()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment:filename=\""+docs.getDocName()+"\"")
				.body(new ByteArrayResource(docs.getDocDate()));
				
	}
}
