package com.rays.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rays.model.Docs;

public interface DocRepo extends JpaRepository<Docs, Integer>{

}
