package com.rays;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
public class EmpController {
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	DiscoveryClient discoveryClient;
	//getEmp/1/2
	@GetMapping("getEmp/{id}/{techId}")
	public Employee getEmployee(@PathVariable int id,@PathVariable int techId) {
		
		Employee emp=empRepo.findEmployee(id);
		
		//Technology tech=new RestTemplate().getForObject("http://localhost:8070/getTech/"+techId, Technology.class);
		
		List<ServiceInstance> list=discoveryClient.getInstances("APPLESERVICE");//Employee,Order,Project
		
		ServiceInstance service=list.get(0);
		//localhost:8090
		URI url=service.getUri();
		
		Technology tech=new RestTemplate().getForObject(url+"/getTech/"+techId, Technology.class);  //    http://localhost:8070/getTech/1000
		
		
		emp.setTechnology(tech);
		
		return emp;
		
	}

}
