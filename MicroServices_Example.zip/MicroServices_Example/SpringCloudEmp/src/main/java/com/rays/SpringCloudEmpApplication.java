package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudEmpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudEmpApplication.class, args);
	}

}
